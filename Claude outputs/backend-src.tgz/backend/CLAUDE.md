# CLAUDE.md — 영천 홍보지도 앱 (백엔드)

> 이 파일은 백엔드 레포 루트에 둔다. **모든 코드 작업 전에 이 규칙을 따른다.**
> 스택: NestJS(Node.js) + PostgreSQL. 이미지: 외부 스토리지(프리사인 업로드).

## 절대 규칙
1. **1파일 1역할.** 한 클래스/한 책임. 못 말하면 쪼갠다.
2. **한 파일 ~200줄 초과 시 분리 검토.** service가 커지면 유스케이스별로 나눈다(`story-create.service.ts`, `story-query.service.ts`).
3. **의존 방향 고정**: `controller → service → repository → database`. 역방향 금지.
4. **레이어 침범 금지**:
   - controller: 라우팅·DTO 검증·응답 반환만. 비즈니스 로직/DB 접근 금지.
   - service: 비즈니스 로직·규칙 검증. HTTP 개념 없음(응답 envelope 직접 만들지 않음).
   - repository: DB 쿼리만.

## 폴더 구조 (반드시 준수)
```
prisma/
   schema.prisma        # DB 모델 정본(모든 테이블 한 곳), Prisma가 관리
   migrations/          # prisma migrate가 생성
src/common/{errors,filters,interceptors,guards,decorators,dto,utils,memory-date}
src/config
src/prisma/
   prisma.module.ts
   prisma.service.ts    # PrismaClient 래퍼(전역 주입)
src/modules/<resource>/
   <resource>.module.ts
   <resource>.controller.ts
   <resource>.service.ts
   <resource>.repository.ts   # PrismaService 통해 DB 접근
   dto/*.dto.ts
```
- **리소스 1개 = 모듈 1개** 세트(controller/service/repository/dto). ORM은 **Prisma**.
- 리소스 목록(ERD v5 기준): auth, user, place, event, story, upload, achievement. (era·place-era 는 2026-10-10 삭제)
- **DB 모델은 `prisma/schema.prisma` 한 파일에 정의**(별도 entity 파일 없음). DTO는 목적별 1파일(`create-story.dto.ts`, `query-story.dto.ts`).
- repository는 `PrismaService`만 사용해 쿼리. service·controller는 PrismaClient를 직접 만지지 않는다.

## 응답·에러 표준 (한 곳에서만)
- 성공 응답 `{ success: true, data }`는 **전역 인터셉터**(`common/interceptors/response.interceptor.ts`)가 래핑. 컨트롤러는 순수 데이터만 반환.
- 에러 `{ success: false, error: { code, message } }`는 **전역 예외 필터**(`common/filters/http-exception.filter.ts`)가 처리.
- 에러 코드·상태코드는 **API 명세서 v4**가 출처(`common/errors/app-error-code.ts` 가 코드 표).

## 검증·인증
- 요청 검증은 DTO(class-validator)로 컨트롤러 경계에서. service는 검증된 값만 받는다.
- 인증은 `common/guards/jwt-auth.guard.ts`. 사용자 주입은 `@CurrentUser()` 데코레이터.

## DB (Prisma)
- 스키마 정본은 `prisma/schema.prisma`. 변경은 **Prisma Migrate로 마이그레이션 생성**(수동 DB 편집·`db push`로 운영 반영 금지).
- 스키마 설명서는 ERD v5.
- 규칙 예: 스토리는 `place_id` 또는 `event_id` 중 최소 하나 필수 → service에서 검증(Prisma로 강제 어려운 CHECK 규칙은 서비스 계층에서).

## 기억 날짜 (memory_date)
- 형식 `YYYY.MM.DD`, 모든 자리 `0-9` 또는 `X`. 정렬용 파생 컬럼(`memory_date_from/to`, `memory_year_from/to`, `memory_year_unknown`)은 **`common/memory-date/memory-date.resolver.ts` 로만** 만든다. 직접 계산·클라이언트 입력 금지.
- 타임라인 정렬은 `story/story-timeline.order.ts` 한 곳에. 규칙 원문은 ERD v5 §3.
- 규칙을 바꾸면 프론트 `lib/core/memory_date/` 와 두 쪽 테스트 사례 표를 같이 고친다.

## 이미지 업로드
- 서버는 파일을 받지 않는다. `upload` 모듈이 프리사인 URL을 발급하고, 클라이언트가 외부 스토리지에 직접 PUT. 서버엔 최종 URL만 저장.

## 하지 말 것
- 컨트롤러에서 DB 직접 접근, service에서 res 객체 조작.
- 응답 envelope을 컨트롤러마다 수동으로 만들기.
- 한 모듈에 여러 리소스 혼합.
- 명세에 없는 필드/엔드포인트 임의 추가(먼저 명세 갱신).

## 작업 방식
- 새 리소스: schema.prisma에 모델 추가 → migrate → module → dto → repository(Prisma) → service → controller 순.
- service 단위 테스트로 핵심 규칙 최소 커버(앵커 검증, 유일성 등).
- 관련 문서: docs/요구사항 정의서, docs/ERD_v5, docs/API명세서_v4, docs/아키텍처정의서.
