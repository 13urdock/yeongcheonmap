// Firebase 연결 (앱 전체에서 한 번만 초기화)
// firebaseConfig 값은 Firebase 콘솔 > 프로젝트 설정 > 내 앱(웹) 에서 복사해 붙여넣는다.
import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: 'REPLACE_ME',
  authDomain: 'REPLACE_ME',
  projectId: 'REPLACE_ME',
  storageBucket: 'REPLACE_ME',
  messagingSenderId: 'REPLACE_ME',
  appId: 'REPLACE_ME',
};

const app = initializeApp(firebaseConfig);

export const db = getFirestore(app);
