// 방명록 데이터 접근 (Firestore 'guestbook' 컬렉션)
// 저장 형태: { content: string, createdAt: 서버 시각 }
import {
  addDoc,
  collection,
  limit,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
} from 'firebase/firestore';
import { db } from './firebaseApp';

export const GUESTBOOK_MAX_LENGTH = 500; // firestore.rules 의 500 과 맞춘다
export const GUESTBOOK_PAGE_SIZE = 50; // firestore.rules 의 list 상한(50) 이하로

const guestbookRef = collection(db, 'guestbook');

/** 새 방명록 글을 남긴다. 앞뒤 공백은 지우고, 빈 글·긴 글은 막는다. */
export async function addGuestbookEntry(rawContent) {
  const content = rawContent.trim();
  if (content.length === 0) {
    throw new Error('내용을 적어주세요.');
  }
  if (content.length > GUESTBOOK_MAX_LENGTH) {
    throw new Error(`${GUESTBOOK_MAX_LENGTH}자까지 남길 수 있어요.`);
  }
  await addDoc(guestbookRef, { content, createdAt: serverTimestamp() });
}

/**
 * 최신 글부터 실시간으로 받아본다.
 * 반환값(unsubscribe)을 호출하면 구독이 끝난다.
 * createdAt 은 방금 쓴 글이 서버에 닿기 전 잠깐 null 일 수 있다.
 */
export function subscribeGuestbookEntries(onEntries, onError) {
  const latestFirst = query(
    guestbookRef,
    orderBy('createdAt', 'desc'),
    limit(GUESTBOOK_PAGE_SIZE),
  );

  return onSnapshot(
    latestFirst,
    (snapshot) => {
      onEntries(
        snapshot.docs.map((doc) => ({
          id: doc.id,
          content: doc.data().content,
          createdAt: doc.data().createdAt?.toDate() ?? null,
        })),
      );
    },
    onError,
  );
}
