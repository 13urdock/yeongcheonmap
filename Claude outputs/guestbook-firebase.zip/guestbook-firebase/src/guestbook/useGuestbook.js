// 방명록 React 훅: 목록 구독 + 글 남기기 상태
import { useCallback, useEffect, useState } from 'react';
import {
  addGuestbookEntry,
  subscribeGuestbookEntries,
} from './guestbookRepository';

export function useGuestbook() {
  const [entries, setEntries] = useState([]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const unsubscribe = subscribeGuestbookEntries(setEntries, () =>
      setError('방명록을 불러오지 못했어요.'),
    );
    return unsubscribe;
  }, []);

  /** 성공하면 true, 실패하면 false (error 에 안내 문구) */
  const submit = useCallback(async (content) => {
    setSubmitting(true);
    setError(null);
    try {
      await addGuestbookEntry(content);
      return true;
    } catch (e) {
      setError(e instanceof Error && e.message ? e.message : '남기지 못했어요.');
      return false;
    } finally {
      setSubmitting(false);
    }
  }, []);

  return { entries, submit, submitting, error };
}
