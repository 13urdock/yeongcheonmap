// 방명록 날짜 표시: 2026.11.08 (서버 반영 전이면 빈 문자열)
export function formatEntryDate(date) {
  if (!date) return '';
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}.${m}.${d}`;
}
